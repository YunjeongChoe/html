package model;

public class OptionsVO {
	
	
	private int no;
	private String subject;
	
	public OptionsVO() {
		
	}

	public OptionsVO(int no, String subject) {
		super();
		this.no = no;
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "OptionsVO [no=" + no + ", subject=" + subject + "]";
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	
	
	
}
