package model;

public class ResultVO {
	
	private int no;
	private String line;
	private int score;
	
	public ResultVO() {
		
	}

	public ResultVO(int no, String line, int score) {
		super();
		this.no = no;
		this.line = line;
		this.score = score;
	}

	@Override
	public String toString() {
		return "[no=" + no + ", line=" + line + ", score=" + score + "]";
	}

	
	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}
	public String getLine() {
		return line;
	}
	
	public void setLine(String line) {
		this.line = line;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	
	
	
	
	
}