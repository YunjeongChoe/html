package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.ResultVO;

public class ResultDao {
	
private static ResultDao instance = new ResultDao();
	
	public static ResultDao getInstance() {
		return instance;
	}
	
	private ResultDao() {
		
	}
	
	
	//랭킹보기 
	public ArrayList<ResultVO> getResult(Connection conn) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("SELECT						");
		query.append("		 no				");
		query.append("		,result_line			");
		query.append("		,result_score			");
		query.append("FROM							");
		query.append("		result					");
		query.append("ORDER BY result_score DESC	");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<ResultVO> result = new ArrayList<>();
		
		while(rs.next()) {
			ResultVO temp = new ResultVO();
			temp.setNo(rs.getInt("no"));
			temp.setLine(rs.getString("result_line"));
			temp.setScore(rs.getInt("result_score"));
			result.add(temp);
		}
		
		if(rs != null) rs.close();
		if(ps != null) ps.close();
		
		return result;
		
		
	}
	
	
	
	
}
