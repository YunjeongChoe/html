package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.OptionsVO;

public class OptionsDao {
	
	private static OptionsDao instance = new OptionsDao();
	
	public static OptionsDao getInstance() {
		return instance;
	}
	
	public ArrayList<OptionsVO> Option(Connection conn) throws SQLException {
		StringBuffer query = new StringBuffer();
		query.append("UPDATE						");
		query.append("		 no						");
		query.append("		,subject				");
		query.append("FROM							");
		query.append("		options					");
		query.append("WHERE  					");
		
		PreparedStatement ps = conn.prepareStatement(query.toString());
		
		ResultSet rs = ps.executeQuery();
		
		ArrayList<OptionsVO> result = new ArrayList<>();
		
		while(rs.next()) {
			OptionsVO temp = new OptionsVO();
			temp.setNo(rs.getInt("no"));
			temp.setSubject(rs.getString("subject"));
			result.add(temp);
		}
		
		if(rs != null) rs.close();
		if(ps != null) ps.close();
		
		return result;
		
	}

}

