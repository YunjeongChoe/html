package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.UsersDao;
import jdbc.ConnectionPool;
import model.UsersVO;

public class UsersService {
	
	private UsersDao dao = UsersDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static UsersService instance = new UsersService();
	
	public static UsersService getInstance() {
		return instance;
	}
	
	private UsersService() {
		
	}
	
	
	//회원가입(INSERT)
	public int registUser(UsersVO user) {
		Connection conn = cp.getConnection();
		try {
			return dao.registUser(conn, user);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		return 0;
	}
	
	
	
	
	
	// 중복체크용
	public boolean dupleCheck(String id) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.dupleCheck(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return false;
	}
	
	
	
	
	
	
	//로그인
	public UsersVO loginUser(String id) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.loginUser(conn, id);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		return new UsersVO();
	}
	
	
	
	//점수update
	public int updateSco(UsersVO user) {
		Connection conn = cp.getConnection();
		
		try {
			return dao.updateSco(conn, user);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return 0;
		
	}

	public ArrayList<UsersVO> getUserList(){
		Connection conn = cp.getConnection();
		
		try {
			return dao.getUserList(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		return new ArrayList<UsersVO>();
	}
	
	
	
	
	
}
