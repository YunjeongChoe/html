package service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.ResultDao;
import jdbc.ConnectionPool;
import model.ResultVO;

public class ResultService {
	
	
	private ResultDao dao = ResultDao.getInstance();
	private ConnectionPool cp = ConnectionPool.getInstance();
	
	private static ResultService instance = new ResultService();
	
	public static ResultService getInstance() {
		return instance;
	}
	
	private ResultService() {
		
	}
	
	public ArrayList<ResultVO> getResultList(){
		Connection conn = cp.getConnection();
		
		try {
			return dao.getResult(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(conn != null) cp.releaseConnection(conn);
		}
		
		return new ArrayList<ResultVO>();
	}
	
	
	
	
	
}